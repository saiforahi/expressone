<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class role_allow extends Model
{
    //
}
